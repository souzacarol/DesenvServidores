<?php

class Layouts{
    function __construct($c,$a,$t = 'default')
    {
        if($t == 'default'){
            require_once 'view/template/topo.php';
            require_once 'view/'.$c.'/'.$a.'.php';
            require_once 'view/template/rodape.php';
        }
    }
}