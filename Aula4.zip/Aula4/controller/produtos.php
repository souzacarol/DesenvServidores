<?php
require_once "model/produtos.php";

class Produtos{
  
    public function cadastrar(){
        if(isset($_POST['codigo'])){
            $produtos = new ProdutosModel;
            $produtos->codigo = $_POST['codigo'];
            $produtos->nome= $_POST['nome'];
            $produtos->preco= $_POST['preco'];

            $produtos->cadastrar();
            echo "Cadastro ok!";
        } else {
            //require_once 'view/usuarios/cadastrar.php';
            $layout = new Layouts('produtos','cadastrar');
        }
    }
}