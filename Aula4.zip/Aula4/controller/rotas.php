<?php

class Rotas{
    function __construct($c,$a)
    {
       try {
           $rota = new $c;
           $rota->$a();
       } catch (\Throwable $th) {
          echo "404 - Página não encontrada";
          //var_dump($th); 
       } 
    }
}