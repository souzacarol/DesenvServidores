<?php
require_once "model/tarefas.php";

class Tarefas{
    public function listar(){
        $dados = new TarefasModel();
        $tarefas = $dados->consultar();
        //require_once "view/tarefas/listar.php";
        $layout = new Layouts('tarefas','listar');
    }
}