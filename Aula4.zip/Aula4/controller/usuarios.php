<?php
require_once "model/usuarios.php";

class Usuarios{
    public function login(){
        if(isset($_POST['usuario'])){
            $usuario = new UsuariosModel;
            $logado = $usuario->verificarLogin(
            $_POST['usuario'],$_POST['senha']);
            // $logado == true
            if($logado){
                echo "Login efetuado com sucesso!";
            } else {
                echo "Falha ao acessar.";
            }
        } else {
            //require_once "view/usuarios/login.php";
            $layout = new Layouts('usuarios','login');
        }
    }

    public function cadastrar(){
        if(isset($_POST['login'])){
            $usuario = new UsuariosModel;
            $usuario->login = $_POST['login'];
            $usuario->senha = $_POST['senha'];

            $usuario->cadastrar();
            echo "Cadastro ok!";
        } else {
            //require_once 'view/usuarios/cadastrar.php';
            $layout = new Layouts('usuarios','cadastrar');
        }
    }
}