<?php

function carregarClasses($nome){
    require_once 'controller/'.
    strtolower($nome).'.php';
}
spl_autoload_register('carregarClasses');

$c = $_GET['c'];
$a = $_GET['a'];
// index.php?c=tarefas&a=listar
//echo "Classe $c e Ação $a";

$c = ucfirst($c);
$rota = new Rotas($c,$a);
exit();

if($c == "tarefas" && $a == "listar"){
    $tarefa = new Tarefas();
    $tarefa->listar();
} elseif($c == "usuarios" && $a == "login") {
    $usuario = new Usuarios();
    $usuario->login();
} elseif($c == "usuarios" && $a == "cadastrar") {
    // index.php?c=usuarios&a=cadastrar
    $usuario = new Usuarios();
    $usuario->cadastrar();
} else {
    echo "Erro 404 - Não encontrado";
}