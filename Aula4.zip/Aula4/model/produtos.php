<?php

class ProdutosModel{
    public $codigo;
    public $nome;
    public $preco;

   
    public function cadastrar(){
        $arquivo = 'produtos.csv';
        // "teste","123"
        $linha = '"'.$this->codigo.'";"'.$this->nome.'";"'.$this->preco.'"'.PHP_EOL;
        $file = fopen($arquivo, 'a');
        fwrite($file,$linha);
        fclose($file);
    }

}