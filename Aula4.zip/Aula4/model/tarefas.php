<?php

class TarefasModel{
    public $titulo;
    public $prazo;

    public function consultar(){
        // TODO - Buscar as tarefas
        $tarefas = array();
        $tarefa = [
            'titulo'=>'Testar',
            'prazo'=>'22/02/2020'];
        array_push($tarefas,$tarefa);
        $tarefa = [
            'titulo'=>'Testar 2',
            'prazo'=>'25/02/2020'];
        array_push($tarefas,$tarefa);
        return $tarefas;       
    }
}