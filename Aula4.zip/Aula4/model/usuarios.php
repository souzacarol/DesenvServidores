<?php

class UsuariosModel{
    public $login;
    public $senha;

    public function verificarLogin($u,$s){
        if($u == "adm" && $s == "123"){
            return true;
        } else {
            return false;
        }
    }

    public function cadastrar(){
        $arquivo = 'usuarios.csv';
        // "teste","123"
        $linha = '"'.$this->login.'";"'.$this->senha.'"'.PHP_EOL;
        $file = fopen($arquivo, 'a');
        fwrite($file,$linha);
        fclose($file);
    }

}