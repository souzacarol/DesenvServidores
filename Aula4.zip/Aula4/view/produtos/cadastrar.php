<h1>Cadastrar Produto</h1>
<form action="" method="post">
Codigo<br>
<input type="text" name="codigo"><br>
Nome<br>
<input type="text" name="nome"><br>
Preco<br>
<input type="text" name="preco"><br>
<button type="submit">Cadastrar</button>
</form>