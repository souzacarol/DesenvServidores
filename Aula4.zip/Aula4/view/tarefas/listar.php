<h1>Listar tarefas</h1>

<table border="1">
    <tr>
        <td>Título</td>
        <td>Data</td>
    </tr>
    <?php foreach($tarefas as $item): ?>
    <tr>
        <td><?= $item['titulo'] ?></td>
        <td><?= $item['prazo'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<?php
/*echo "<pre>";
var_dump($tarefas);
echo "</pre>";*/