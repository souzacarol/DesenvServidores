<h1>Cadastrar usuário</h1>
<form action="" method="post">
Login<br>
<input type="text" name="login"><br>
Senha<br>
<input type="text" name="senha"><br>
<button type="submit">Cadastrar</button>
</form>