<form action="" method="post">
    Login:<br>
    <input type="text" name="usuario">
    <br>
    Senha:<br>
    <input type="password" name="senha">
    <br>
    <button type="submit">
        Acessar
    </button>
</form>