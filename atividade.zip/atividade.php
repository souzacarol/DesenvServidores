<?php

$A = 10;
$a = $A + 10;
$B = 20;
$b = $B - 10;
echo "O valor de A $a, valor de B $b";

echo "<hr>";

// Salario
$Salario = 1.900;
$Percentual = 1900 / 10;
echo "O percentual é R$ $Percentual reais";

echo "<hr>";

//Maças
$M = 130;
$total = $M / 10;
echo "10 Maças valem R$ $total reais";

echo "<hr>";

//Valore
$A = 3;
$B = 2;
$C = 7;

$triangulo = $A + $B;
echo "Pode se formar um triangulo, numero dado foi $triangulo";

echo "<hr>";

// Inteiro 
$N = 12;
echo intval($N);

echo "<hr>";

//Turma

$a = 6;
$b = 1;
$c = 5;
echo "Contem 3 alunos a media da turma é    ";
echo ($a + $b + $c / 2);

echo "<hr>";

// Temperatura

$j = 32;
$f = 30;
$m = 15;
$a = 35;
$mai = 25;
$jn = 25;
$jl = 21;
$ag = 22;
$s = 23;
$o = 22;
$n = 36;
$d = 15;

$media = $j + $f + $m + $a + $mai + $jn + $jl + $ag + $s + $o + $n + $d / 12;

echo "$media";

echo "<hr>";

//Angra dos Reis

$massa = 1 ;
$perde = $massa/25-0.2;

echo $perde;

echo "<hr>";

//soma e subtração

$a = 1;
$b = 10;
$c = 4;
$d = 9;
$soma = ($a + $b);
$multi = ($b + $d);
echo " Valor da soma $soma, valor da multiplicação $multi  /";
echo "  $a+$c é maior $b+$d / $a+$c é menor que $b+$d /$a+$c é igual a $b+$d";

echo "<hr>";

//Fatorial

$i = 5;
$calc = 1;
while ($i > 1){
    $calc *= $i;
    $i--;
}

echo "O Fatorial de 5 é $calc";

echo "<hr>";

// Contator

$contador = 0;
while($contador <= 10)
{
    echo   $contador ;

    $contador++;    
} 
 
echo "<hr>";

//Dias

$inicial = '31-01-2020';
$final = '18-02-2020';

// Calcula a diferença em segundos entre as datas
$diferenca = strtotime($final) - strtotime($inicial);

//Calcula a diferença em dias
$dias = floor($diferenca / (60 * 60 * 24));

echo "A diferença é de $dias entre as datas";

echo "<hr>";

